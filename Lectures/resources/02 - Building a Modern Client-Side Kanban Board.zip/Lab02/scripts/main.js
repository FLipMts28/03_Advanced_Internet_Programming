import { CanvasDrawer } from './CanvasDrawer.js';

const canvas = document.getElementById('displayed-canvas');
const drawer = new CanvasDrawer(canvas);